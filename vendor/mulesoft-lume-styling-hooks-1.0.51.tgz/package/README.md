# `@mulesoft/lume-styling-hooks`

## About

Global Styling hooks for Lume use CSS custom properties which make it easy to customize application-wide styling.

[Storybook Environment (coming soon)](TBD)

## Using `lume-styling-hooks`
There are a couple different ways to use `lume-styling-hooks` in your project. We will go over each one below.

### Note
If you're using `lume-foundation` your don't have to manually include `lume-styling-hooks` as it will be already included with the foundation package.

### Anypoint CDN
By using the Anypoint CDN to load the styling hooks CSS you don't need to install the `lume-styling-hooks` package in your project. You also won't need to worry about updating the package version and will get all the latest and greatest updates automatically every time we release a new version of `lume-styling-hooks`.   
To start using `lume-styling-hooks` from the CDN all you have to do is to include the following stylesheet link in your main HTML file.

```HTML
<html>
  <head>
    <link rel="stylesheet" href="/lume/lume-styling-hooks/index.css"/>

    <!-- Your application's stylesheets go below -->
    <link rel="stylesheet" href="..."/>
  </head>
  <body>
    <!-- Your application -->
  </body>
</html>
```

When hosting your application locally for development, you will want to either replace the URL above with the full CDN URL or configure your local webserver to redirect the URL above to the CDN URL.

### Project Dependency
If your application is not hosted within the Anypoint webserver or if you don't want to use the CDN method above, you can also install the `lume-styling-hooks` as a dependency in your project. Keep in mind that with this method you will be responsible to update `lume-styling-hooks` package versions in your project so to keep your application updated with the latest styles and themes provided by the Lume Design System.  

To get started, install the package as a dev-dependency with npm.
```
npm i @mulesoft/lume-styling-hooks
```

After installing the package, all the distributables for the `lume-styling-hooks` are available on the folder `@mulesoft/lume-styling-hooks/dist`.
|File Name |Description |
|- |- |
|`index.css` | The Compiled CSS file for `lume-styling-hooks` package|
|`index.js` | ES module that exports the Compiled CSS file for `lume-styling-hooks` package|

There are different ways you can use the installed package in your application, depending on the requirement. It can be used both in light DOM and shadow DOM. Below are the different ways you can use it.

#### HTML
As with the CDN approach, you can use the `<link>` tag to include `lume-styling-hooks` directly into your application main HTML file.

```HTML
<html>
  <head>
    <link rel="stylesheet" href="/node_modules/@mulesoft/lume-styling-hooks/dist/index.css"/>

    <!-- Your application's stylesheets go below -->
    <link rel="stylesheet" href="..."/>
  </head>
  <body>
    <!-- Your application -->
  </body>
</html>
```

#### CSS
You can use CSS `@import` to pull in `lume-styling-hooks` directly into your application CSS.

```CSS
@import '@mulesoft/lume-styling-hooks/dist/index.css'
```

#### JS
You can use ES modules `import` directly into our application JS.

```javascript
import css from '@mulesoft/lume-styling-hooks/dist/index.css'
```

## Examples of styling hooks
Types can be described in two relationships, **one-to-one** and **one-to-many**. If we look at these relationships through the lens of the HTML document, we can describe CSS Custom Properties as:
- one-property-to-one-property,
- one-property-to-many-properties,
- one-property-to-many-components,
- one-property-to-one-element,
- and one-property-to-many-elements.
Using types in addition to our scopes, we have clarity around the Styling Hook's intent.

### Global hooks
Typically, global hooks have a **one-property-to-many-properties** relationship since it's less prescriptive, that is, *"I want to apply my brand color to many backgrounds, borders, text, etc."*    
Global hooks will have the letter **g** added to the custom property name right after the lume namespace, as in `--lume-g-*`.    
For example:
```css
a {
  color: var(--lume-g-color-core-blue-1);
}
.brand-accent {
  background-color: var(--lume-g-color-core-blue-3);
}
```

### Shared hooks

Typically, shared hooks have a **one-property-to-many-components** relationship since we only want to share properties of semantically similar components, that is, *"I want to change the background color of my form elements."*.    
Shared hooks will have the letter **s** added to the custom property name right after the lume namespace, as in `--lume-s-*`.    
For example:

```css
input[type="text"] {
  border-color: var(--lume-s-input-color-border);
}
input[type="checkbox"] {
  border-color: var(--lume-s-input-color-border);
}
```

### Component hooks

Typically, component hooks have a **one-property-to-one-element** relationship, that is, *"I only want to affect the font-size of my component's text heading"*. Additionally, Component hooks can have a **one-property-to-many-elements** relationship, i.e., *"All the borders in my component shared size of 2px"*.    
Component hooks will have the letter **c** added to the custom property name right after the lume namespace, as in `--lume-c-*`.    
For example:

```css
/* Application defined */
:host {
  --lume-c-card-sizing-border: 2px;
  --lume-c-card-title-font-size: 1.2rem;
}

/* Card Component */
[part="card"] {
  border-width: var(--lume-c-card-sizing-border);
}
[part="title"] {
  font-size: var(--lume-c-card-title-font-size);
}
[part="footer"] {
  border-width: var(--lume-c-card-sizing-border);
}
```


### Compounding hooks
When using styling hooks to give users the ability to change the look and feel of components and allow application theming, it's best practive to compound the styling hooks in a way that if a higher level hook is defined in the application, that hook takes precedence of a lower level hook, even if the lower level hook is also defined. And if no hook is defined at all, a fallback value can be used, when it makes sense.    

In the example below we're defining the text color of button to be first the value of `--lume-c-button-color`, if that custom property is not defined in the application where this button is being used, then the next value it will try to use is `--lume-s-button-color`, if that custom property is also not defined then it will try `--lume-g-color-core-blue-1` and if that's not defined nothing will be set for this CSS style and the browser will disregard this CSS rule.
```css
[part="button"] {
  color: var(--lume-c-button-color, var(--lume-s-button-color, var(--lume-g-color-core-blue-1)));
}
```

When it makes sense, that compounding can go even one more level down and define the actual fallback value to be used in case not custom property at all is defined. In the example below the value `#eef4ff` would be applied to the CSS property `color` in case none of the custom properties is defined.
```css
[part="button"] {
  color: var(--lume-c-button-color, var(--lume-s-button-color, var(--lume-g-color-core-blue-1, "#eef4ff")));
}
```

For more information, please visit [SDS styling hooks](https://github.com/salesforce-ux/salesforce-design-system/tree/main/packages/sds-styling-hooks) readme.
